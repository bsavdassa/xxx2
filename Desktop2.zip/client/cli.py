import websocket
import _thread
import time
import rel
import json
from PIL import Image
import numpy as np
import time
import asyncio


async def main():
    async def loopX():
        print("xx")
        await asyncio.sleep(2)
    def on_message(ws, message):
        pixels = json.loads(message)["image"]["data"];
        with open("new3.png","wb") as ofile:
            ofile.write(bytes(pixels));
        # # pixels =[226, 137, 125, 226, 137, 125, 223, 137, 133, 223, 136, 128, 226, 138, 120, 226, 129, 116, 228, 138, 123, 227, 134, 124, 227, 140, 127, 225, 136, 119, 228, 135, 126, 225, 134, 121, 223, 130, 108, 226, 139, 119, 223, 135, 120, 221, 129, 114, 221, 134, 108, 221, 131, 113, 222, 138, 121, 222, 139, 114, 223, 127, 109, 223, 132, 105, 224, 129, 102, 221, 134, 109, 218, 131, 110, 221, 133, 113, 223, 130, 108, 225, 125, 98, 221, 130, 121, 221, 129, 111, 220, 127, 121, 223, 131, 109, 225, 127, 103, 223] 
        # # Convert the pixels into an array using numpy
        # array = np.array(pixels, dtype=np.uint8)
        # # Use PIL to create an image from the new array of pixels
        # new_image = Image.fromarray(array)
        # new_image.save('new.png')
    def on_error(ws, error):
        print(error)

    def on_close(ws, close_status_code, close_msg):
        print("### closed ###")

    def on_open(ws):
        print("Opened connection")
        ws.send("xxx")

    if __name__ == "__main__":
        websocket.enableTrace(True)
        ws = websocket.WebSocketApp("ws://localhost:9999",
                                on_open=on_open,
                                on_message=on_message,
                                on_error=on_error,
                                on_close=on_close)
        # await loopX();
        await asyncio.gather(loopX());
        ws.run_forever(dispatcher=rel)  # Set dispatcher to automatic reconnection
        rel.signal(2, rel.abort)  # Keyboard Interrupt
        rel.dispatch()

# asyncio.run(main());
asyncio.run(main())
# loop = asyncio.get_event_loop();
# loop.run_until_complete(main());